from Crypto.Util.number import getPrime


p = getPrime(512)
q = getPrime(512)


N = p * q

with open("flag.txt", "rb") as f:
    flag = f.read().strip() 

e1 = 65537  
e2 = 10000019


m = int.from_bytes(flag, byteorder='big')


c1 = pow(m, e1, N)
c2 = pow(m, e2, N)

